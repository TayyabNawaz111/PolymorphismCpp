#include"BasicShape.h"

double BasicShape::getArea(){
	return area;
}
void  BasicShape::setArea(double a){
	this->area = a;
}
void BasicShape::display(){
	cout << "Area: " << this->getArea() << endl;
}