#include "Reactangle.h"

double Rectangle::getWidth(){
	return width;
}
double Rectangle::getLength(){
	return length;
}
void Rectangle::calcArea(){
	this->setArea(getWidth()*getLength());
}
Rectangle::Rectangle(double l, double w){
	this->length = l;
	this->width = w;
	calcArea();
}