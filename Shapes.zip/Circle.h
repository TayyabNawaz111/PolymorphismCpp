#ifndef C
#define C
#include "BasicShape.h"
class Circle :public BasicShape{
	double centerX, centerY, radius;
public:
	double getCenterX();
	double getCenterY();
	Circle(double x, double y, double r);
	void calcArea();
};
#endif 
