#include "Circle.h"
#include "Reactangle.h"
int main(){
	BasicShape *bs[2];
	Circle c(12, 20, 5.4);
	Rectangle r(5.3, 3.5);
	bs[0] = &c;
	bs[1] = &r;
	for (int i = 0; i < 2; i++){
		if (i == 0)
			cout << "Circle\n";
		else
			cout << "Recangle\n";
		bs[i]->display(); //polymorphism -> single call different implementation
		cout << "---------------\n";
	}
	system("pause");
	return 0;
}