#ifndef R
#define R
#include "BasicShape.h"
class Rectangle :public BasicShape{
	double width, length;
public:
	double getWidth();
	double getLength();
	void calcArea();
	Rectangle(double l, double w);
};
#endif
