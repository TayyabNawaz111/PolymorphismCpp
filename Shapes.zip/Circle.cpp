#include "Circle.h"
double Circle::getCenterX(){
	return centerX;
}
double Circle::getCenterY(){
	return centerY;
}
void Circle::calcArea(){
	this->setArea((3.14159*(getCenterX() / getCenterY())*radius));
}
Circle::Circle(double x, double y,double r){
	centerX = x;
	centerY = y;
	radius = r;
	calcArea();
}