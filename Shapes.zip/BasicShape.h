#include <iostream>
using namespace std;
#ifndef BS
#define BS

class BasicShape{
	double area;
public:
	double getArea();
	void setArea(double a);
	virtual void calcArea() = 0;
	virtual void display();
};
#endif 