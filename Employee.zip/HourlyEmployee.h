#ifndef H_EMPLOYEE
#define H_EMPLOYEE
#include "Employee.h"
class HourlyEmployee : public Employee{
	double HourlyRate;
	int hours_worked;
public:
	HourlyEmployee(char* name , double hr , int hw );
	double getHourlyRate();
	int getHours_worked();
	void setHourlyRate(double r);
	void setHours_worked(int h);
	double calculatePay();
	void displayDetails();
};
#endif