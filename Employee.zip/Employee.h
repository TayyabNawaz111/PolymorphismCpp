#ifndef EMPLOYEE
#define EMPLOYEE
#pragma warning(disable:4996)
#include <iostream>
#include <string>
using namespace std;
class Employee{
	char *name;
public:
	virtual double calculatePay();
	virtual void displayDetails();
	void setName(char *name);
	char *getName();
	Employee(char *name = nullptr);
	~Employee();

};
#endif