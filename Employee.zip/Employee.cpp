#include "Employee.h"
double Employee::calculatePay(){
	return NULL;
}


void Employee::displayDetails(){
	cout << "Name: " << this->getName() << endl;
}
void Employee::setName(char *name){
	this->name = new char[strlen(name) + 1];
	strcpy(this->name, name);
}
char* Employee::getName(){
	return this->name;
}
Employee::Employee(char *name){
	this->setName(name);
}
Employee::~Employee(){
	delete[]name;
}