#include "SalariedEmployee.h"
#include "HourlyEmployee.h"
int main(){
	Employee *e[2];
	HourlyEmployee he("Ubaid Ullah", 150, 12);
	SalariedEmployee se("Usama", 34000);
	e[0] = &he;
	e[1] = &se;
	for (int i = 0; i < 2; i++)
	{
		e[i]->displayDetails(); //polymorphism
		cout << "-----------------------------------\n";
	}
	system("pause");
	return 0;
}