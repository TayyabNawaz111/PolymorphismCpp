#include "SalariedEmployee.h"
double SalariedEmployee::getMonthlySalary(){
	return this->monthlySalary;
}
void SalariedEmployee::setMonthlySalary(double s){
	this->monthlySalary = s;
}
SalariedEmployee::SalariedEmployee(char *name , double s ) :Employee(name){
	this->setMonthlySalary(s);
}
double SalariedEmployee::calculatePay(){
	return this->getMonthlySalary();
}
void SalariedEmployee::displayDetails(){
	cout << "\nSalaried Employee:\n";
	Employee::displayDetails();
	cout << "Pay: " << this->getMonthlySalary() << endl << endl;
}