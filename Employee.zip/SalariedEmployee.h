#ifndef S_EMPLOOYEE
#define S_EMPLOYEE
#include "Employee.h"
class SalariedEmployee : public Employee{
	double monthlySalary;
public:
	double getMonthlySalary();
	void setMonthlySalary(double s);
	SalariedEmployee(char *name = nullptr, double s = 0);
	double calculatePay();
	void displayDetails();
};
#endif 