#include "HourlyEmployee.h"
HourlyEmployee::HourlyEmployee(char* name = nullptr, double hr = 0, int hw = 0) :Employee(name){
	this->setHourlyRate(hr);
	this->setHours_worked(hw);
}
double HourlyEmployee::getHourlyRate()
{
	return this->HourlyRate;
}
int HourlyEmployee::getHours_worked(){
	return this->hours_worked;
}

void HourlyEmployee::setHourlyRate(double r){
	this->HourlyRate = r;
}
void HourlyEmployee::setHours_worked(int h){
	this->hours_worked = h;
}
double HourlyEmployee::calculatePay(){
	return (this->getHours_worked()*this->getHourlyRate());
}
void HourlyEmployee::displayDetails(){
	cout << "Hourly Employee:\n";
	Employee::displayDetails();
	cout << "Pay: " << calculatePay() << endl;
}